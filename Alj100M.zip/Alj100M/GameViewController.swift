//
//  GameViewController.swift
//  Alj100M
//
//  Created by 山本拓哉 on 2020/06/08.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {

    
    
    @IBOutlet weak var CountLabel: UILabel!
    @IBOutlet weak var Cara1: UIImageView!
    @IBOutlet weak var Cara2: UIImageView!
    @IBOutlet weak var ase1: UIImageView!
    @IBOutlet weak var ase2: UIImageView!
    @IBOutlet weak var ganba1: UIImageView!
    @IBOutlet weak var ganba2: UIImageView!
    @IBOutlet weak var goal: UIImageView!
    
    
    var CountInt:Int = 0
    var timer:Timer!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //文字列へ変換
        CountLabel.text = CountInt.description
        
        //非表示
        Cara1.isHidden = true
        ase1.isHidden = true
        ase2.isHidden = true
        ganba1.isHidden = true
        ganba2.isHidden = true
        goal.isHidden = true
         
         //表示
        Cara2.isHidden = false
        
         //timer変数へNSTimer関数(0.1秒間毎にonUpdate関数を実行させる)を入れる
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.onUpdate(timer:)), userInfo: nil, repeats: true)
        
        
        
    }
    
    //timer処理
    @objc func onUpdate(timer : Timer){
        CountTimer = CountTimer + 0.1
    }
    
    @IBAction func rendaButton(_ sender: Any) {
        
     
        if Cara1.isHidden == true {
            
            Cara1.isHidden = false
            Cara2.isHidden = true
        } else{
            
            Cara1.isHidden = true
            Cara2.isHidden = false
        }
        
       
        CountInt = CountInt + 1
        
        //文字列変換
        CountLabel.text = CountInt.description
        
        if CountInt > 90{
            
            if ase1.isHidden == false{
                ase1.isHidden = true
                ase2.isHidden = false
            }else{
                ase1.isHidden = false
                ase2.isHidden = true
            }

            if ganba1.isHidden == false{
                ganba1.isHidden = true
                ganba2.isHidden = false
            }else{
                ganba1.isHidden = false
                ganba2.isHidden = true
            }

            if goal.isHidden == true{
                goal.isHidden = false
            }
            
        }
        
        //100で画面遷移
        if CountInt == 100 {
            
            //停止
            timer.invalidate()
            
            //画面を遷移させる
            self.performSegue(withIdentifier: "toResult", sender: nil)
        }
        
        
    }
    
    
    

    
}
