//
//  ViewController.swift
//  DollarYen
//
//  Created by 山本拓哉 on 2020/06/04.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{
    
    //入力通貨の単位
    @IBOutlet weak var inputCurrency: UILabel!
    //金額入力フィールド
    @IBOutlet weak var inputField: UITextField!
    //通貨のレートを表示
    @IBOutlet weak var rateLabel: UILabel!
    //換算項目を選ぶSegmented Control
    @IBOutlet weak var selector: UISegmentedControl!
    //換算後の金額
    @IBOutlet weak var resultLabel: UILabel!
    //換算後の通貨の単位を表示
    @IBOutlet weak var resultCurrency: UILabel!
    
    //入力金額
    var input = Double()
    //換算後の金額
    var result = Double()
    //変換レート
    var rate = Double()
    //円ドル切替
    var isYenToDoller = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        inputField.delegate = self
        
        rate = 120.0
        input = 0
        result = 0
        //小数点一桁までrateで更新
        rateLabel.text = String(format: "%.1f",rate)
        //最初は円からドル
        isYenToDoller = true
        
    }
    
    //通貨の計算
    func convert(){
        //円→ドルの変換
        if isYenToDoller == true{
            result = input / rate
            resultLabel.text = String(format: "%.2f", result)
            
        }else if isYenToDoller == false{
            result = input * rate
            resultLabel.text = String(format: "%.0f", result)
        }
    }
    
    
    @IBAction func changeCalcMethod(sender: AnyObject) {
        
        if sender.selectedSegmentIndex == 0 {
            isYenToDoller = true
            inputCurrency.text = "円"
            resultCurrency.text = "ドル"
        } else if sender.selectedSegmentIndex == 1 {
            isYenToDoller = false
            inputCurrency.text = "ドル"
            resultCurrency.text = "円"
        }
    
        self.convert()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        input = atof(textField.text)
        textField.resignFirstResponder()
        self.convert()
        return true
    }

}

