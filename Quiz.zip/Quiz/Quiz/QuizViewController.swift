//
//  QuizViewController.swift
//  Quiz
//
//  Created by 山本拓哉 on 2020/06/05.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class QuizViewController: UIViewController {
    
    
    @IBOutlet weak var problemText: UITextView!
    
    
    
    //問題の配列
    var problemSet = NSMutableArray()
    //問題数
    var totalProblems = Int()
    //出題済み問題数を記録
    var currentProblem = Int()
    //正答数
    var correctAnswers = Int()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //問題を読み込み
        self.loadProblemSet()
        //シャッフルのメソッドを呼び出し
        self.shuffleProblemSet()
        
        //問題数を１０問
        totalProblems = 10
        
        //問題数と正当数を０で初期化
        currentProblem = 0
        correctAnswers = 0
        
        //クイズ画面に問題文をセット
        let questions = problemSet.object(at: currentProblem) as! Problem
        problemText.text = questions.getQ()
    }
    
    
    
    func loadProblemSet() {
       // ファイルを読み込む
       let path = Bundle.main.path(forResource: "quiz", ofType: "csv")
    
       let enc = String.Encoding.utf8
       let data = NSData(contentsOfFile: path!)
        let text = String(NSString(data: data! as Data, encoding: enc.rawValue)!)
       // linesに格納（行ごとに分割）
       let lines = text.components(separatedBy: "\n")
       // 問題の数繰り返し
       for i in 0..<lines.count {
           //itemsにカンマで区切って格納
           let items = lines[i].components(separatedBy: ",")
           //問題文と答えを格納
           let p = Problem()
           let q = items[0]
           let a = Int(items[1])
           p.setQ(q: q, a: a!)
           //Problemのインスタンスに追加
           problemSet.add(p)
       }
    }
    
    //問題をシャッフル
    func shuffleProblemSet() {
        //全部の問題数を取得
        let totalQuestions = problemSet.count
        //カウンター
        var i = totalQuestions
        //配列要素をシャッフル
        while i > 0 {
            //乱数を発生
            let j = arc4random() % UInt32(i)
            //要素を並び替え
            problemSet.exchangeObject(at: i-1, withObjectAt: Int(j))
            //カウンターを減少させる
            i -= 1
        }
    }
    
    func nextProblem() {
        //問題数を繰り上げ
        currentProblem += 1
        //問題がまだあるなら次の問題を表示
        if currentProblem < totalProblems {
            
            let questions = problemSet.object(at: currentProblem) as! Problem
            problemText.text = questions.getQ()
            //問題がないなら
        } else {
            //結果表示画面へ
            self.performSegue(withIdentifier: "toResultView", sender:self)
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //正答率を算出
        let percentage = correctAnswers * 100 / totalProblems
        
        //ResultViewController（RVC）のインスタンスを作成し、
        //RVCクラスのメンバー変数である「correctPercentage」に値を渡す
        if segue.identifier == "toResultView" {
            let rvc = segue.destination as! ResultViewController
            rvc.correctPercentage = percentage
        }
    }
    
    
    
    
    
    
    
    
    
    //丸ボタン
    @IBAction func answerIsTrue(_ sender: Any) {
        
        let questions = problemSet.object(at: currentProblem) as! Problem
        if questions.getA() == 0 {
            correctAnswers += 1;
        }
        self.nextProblem()
        
    }
    
    //罰ボタン
    @IBAction func answerIsFalse(_ sender: Any) {
        let questions = problemSet.object(at: currentProblem) as! Problem
        if questions.getA() == 1 {
            correctAnswers += 1;
        }
        self.nextProblem()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
