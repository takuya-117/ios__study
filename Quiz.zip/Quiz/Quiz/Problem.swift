//
//  Problem.swift
//  Quiz
//
//  Created by 山本拓哉 on 2020/06/05.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class Problem: NSObject {
    var question = String()
    
    var answer = Int()
    
    func setQ(q: String, a: Int){
        question = q
        answer = a
    }
    
    func getQ() -> String{
        return question
    }
    
    func getA() -> Int{
        return answer
    }

}
