//
//  ViewController.swift
//  Quiz
//
//  Created by 山本拓哉 on 2020/06/05.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backView(segue: UIStoryboardSegue){
        
    }


}

