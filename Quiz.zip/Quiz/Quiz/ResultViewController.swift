//
//  ResultViewController.swift
//  Quiz
//
//  Created by 山本拓哉 on 2020/06/05.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var percentageLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var levelImage: UIImageView!
    
    //クイズ画面から渡させる値
    var correctPercentage = Int()
  
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if correctPercentage < 30 {
            levelLabel.text = "猿レベル"
            levelImage.image = UIImage(named:"bad")
        } else if correctPercentage >= 30 && correctPercentage < 90 {
            levelLabel.text = "一般人レベル"
            levelImage.image = UIImage(named:"normal")
        } else if correctPercentage >= 90 {
            levelLabel.text = "天才レベル"
            levelImage.image = UIImage(named:"good")
        }
        //実際の正答率を表示
        percentageLabel.text = String(format:"%d %%", correctPercentage)
    }
}
