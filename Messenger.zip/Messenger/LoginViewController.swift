//
//  LoginViewController.swift
//  Messenger
//
//  Created by 山本拓哉 on 2020/06/15.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit
import NCMB

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //パスワードは非表示
        passwordTextField.isSecureTextEntry = true
    }
    
    @IBAction func loginButtonTapped(_ sender: Any) {
        // NCMBログイン
        let userId = userIdTextField.text!
        let password = passwordTextField.text!
        NCMBUser.logInWithUsername(inBackground: userId, password: password, block:({(user, error) in
            if (error != nil){
                print("ログイン失敗:\(error)")
            }else{
                print("ログイン成功:\(user)")
                // トップ画面へ戻る
                _ = self.navigationController?.popToRootViewController(animated: true)
            }
        }))
    }
    
    

}
