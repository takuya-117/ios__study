//
//  UserRegisterViewController.swift
//  Messenger
//
//  Created by 山本拓哉 on 2020/06/15.
//  Copyright © 2020 ALJ 山本拓哉. All rights reserved.
//

import UIKit
import NCMB

class UserRegisterViewController: UIViewController {

    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //パスワードは非表示
        passwordTextField.isSecureTextEntry = true
    }
    

    @IBAction func userRegisterButtonTapped(_ sender: Any) {
        // NCMBユーザインスタンス
        let user = NCMBUser()
        user.userName = self.userIdTextField.text
        user.password = self.passwordTextField.text
        // 読み込みのみ可能にする
        let acl = NCMBACL()
        acl.setPublicReadAccess(true)
        user.acl = acl
        // ユーザ登録
        user.signUpInBackground({(error) in
            if (error != nil){
                print("ユーザ登録失敗:\(error)")
            }else{
                print("ユーザ登録完了")
                // アラート
                let alert = UIAlertController(title: "登録完了", message: "ユーザ登録完了しました。", preferredStyle: .alert)
                alert.addAction(UIAlertAction(
                    title: "OK",
                    style: .default,
                    handler: {(action:UIAlertAction) -> Void in
                        _ = self.navigationController?.popToRootViewController(animated: true)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        })
    }
    

}
